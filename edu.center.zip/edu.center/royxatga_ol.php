<?php
session_start();
$server="localhost";
$foydalanuvchi="root";
$foydalanuvchi_paroli="root";
$mb_nomi="blog";
$bazaga=new mysqli($server, $foydalanuvchi, $foydalanuvchi_paroli, $mb_nomi);
if ($bazaga->connect_error)
{
    die("Bazaga ulanishda xatolik yuz berdi:" .$bazaga->connect_error);
}
$fish=$_POST["fish"];
$login=$_POST["loginjon"];
$parol1=$_POST["parol1"];
$parol2=$_POST["parol2"];
if(!empty($fish)and !empty($login) and !empty($parol1) and !empty($parol2))
{
    if($parol1===$parol2)
    {
        $parol = hash("sha256", $parol1);
        $loginga_sorov= mysqli_query($bazaga, "SELECT * FROM users WHERE login='$login'");
        $ajuvoz_natijasi = mysqli_fetch_array($loginga_sorov);
        if($login===$ajuvoz_natijasi["login"])
        {
            $_SESSION["maydon_haqida"] = 'bunday login mavjud iltimos boshqa login kiriting';
            header("Location:identifikatsiya.php");
        }
        else {
            $yubor_baza = mysqli_query($bazaga, "INSERT INTO users(fish, login, parol, rol_id, faolligi)VALUES('$fish', '$login', '$parol', '2', '1')");
            if($yubor_baza===true)
            {
                $_SESSION["xabar_loginga"] = "Ro'yxatdan o'tganingiz uchun rahmat.";
                header("Location:login.php");
            }
            else
            {$_SESSION["maydon_haqida"]="Bazaga yozilmadi, tizimda muammo bor";
            header("Location:identifikatsiya.php");
            }
        }
        }
        else{
            $_SESSION["maydon_haqida"]="parolni takrorlashda xatolik yuz berdi";
            header("Location:identifikatsiya.php");
        }
    }

?>