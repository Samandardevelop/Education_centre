<?php
session_start();
$server="localhost";
$foydalanuvchi="root";
$foydalanuvchi_paroli="root";
$mb_nomi="edu_center.log";
$bazaga=new mysqli($server, $foydalanuvchi, $foydalanuvchi_paroli, $mb_nomi);
if ($bazaga->connect_error)
{
    die("Bazaga ulanishda xatolik yuz berdi:" .$bazaga->connect_error);

}
$login=$_POST["name"];
$mail=$_POST["email"];
$password=$_POST["parol"];
$pass=$_POST["parol2"];

if(!empty($fish)and !empty($login)and !empty($email)and !empty($password)and !empty($pass))

{
    if($password===$pass){
        $parol=hash("sha256", $password);
        $loginga_sorov=mysqli_query($bazaga, "SELECT * FROM loginlar WHERE name='$login'");
        $natija=mysqli_fetch_array($loginga_sorov);
        if($login===$natija["login"])
        {
            $_SESSION["maydon_haqida"] = 'bunday login mavjud iltimos boshqa login kiriting!';
            header("Location:sahifa.php");
        }
        else
        {
            $yubor = mysqli_query($bazaga, "INSERT INTO loginlar(name, email, parol)VALUES('$login', '$mail', '$parol')");
            if($yubor===true)
            {
                $_SESSION["xabar_loginga"] = 'Ro`yxatdan o`tganingiz uchun rahmat';
                header("Location:sahifa.php");
            }
            else
            {
                $_SESSION["maydon_haqida"]="Bazaga yozilmadi, tizimda muammo bor";
                header("Location:sahifa.php");
                
            }
        }
    }
    else
    {
        $_SESSION["maydon_haqida"]="parolni takrorlashda xatolik yuz berdi";
        header("Location:sahifa.html");
    }
}
 
?>